﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_b7
{
    public class Destination
    {
        public int distance;
        public string name;

        public Destination(int distance, string name) {
            this.distance = distance;
            this.name = name;
        }
    }
}
